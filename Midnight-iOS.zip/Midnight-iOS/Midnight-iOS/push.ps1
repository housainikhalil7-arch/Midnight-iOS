# Easy Push Script for Midnight-iOS

Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║         MIDNIGHT-IOS - GITHUB PUSH HELPER                  ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

# Check if git is initialized
if (-not (Test-Path ".git")) {
    Write-Host "✗ Git not initialized. Run setup first." -ForegroundColor Red
    exit 1
}

# Get GitHub username
Write-Host "Enter your GitHub username: " -ForegroundColor Yellow -NoNewline
$username = Read-Host

if ([string]::IsNullOrWhiteSpace($username)) {
    Write-Host "✗ Username required!" -ForegroundColor Red
    exit 1
}

# Get repository name
Write-Host "Enter repository name [Midnight-iOS]: " -ForegroundColor Yellow -NoNewline
$repoName = Read-Host
if ([string]::IsNullOrWhiteSpace($repoName)) {
    $repoName = "Midnight-iOS"
}

# Build the remote URL
$remoteUrl = "https://github.com/$username/$repoName.git"

Write-Host "`nRepository URL: $remoteUrl" -ForegroundColor Cyan

# Check if remote exists
$existingRemote = git remote get-url origin 2>$null
if ($existingRemote) {
    Write-Host "`nRemote 'origin' already exists: $existingRemote" -ForegroundColor Yellow
    Write-Host "Do you want to replace it? (y/n): " -NoNewline
    $replace = Read-Host
    if ($replace -eq 'y' -or $replace -eq 'Y') {
        git remote remove origin
        Write-Host "✓ Removed old remote" -ForegroundColor Green
    } else {
        Write-Host "Using existing remote..." -ForegroundColor Gray
        $remoteUrl = $existingRemote
    }
}

# Add remote if not exists
if (-not (git remote get-url origin 2>$null)) {
    Write-Host "`nAdding remote..." -ForegroundColor Yellow
    git remote add origin $remoteUrl
    Write-Host "✓ Remote added" -ForegroundColor Green
}

# Update git config
Write-Host "`nEnter your email for git commits: " -ForegroundColor Yellow -NoNewline
$email = Read-Host
if (-not [string]::IsNullOrWhiteSpace($email)) {
    git config --global user.name $username
    git config --global user.email $email
    Write-Host "✓ Git config updated" -ForegroundColor Green
}

Write-Host "`n=== READY TO PUSH ===" -ForegroundColor Cyan
Write-Host "`nThis will push to: $remoteUrl" -ForegroundColor White
Write-Host "Branch: iOS`n" -ForegroundColor White

Write-Host "Make sure you've created the repository on GitHub first!" -ForegroundColor Yellow
Write-Host "Visit: https://github.com/new`n" -ForegroundColor Cyan

Write-Host "Push now? (y/n): " -ForegroundColor Yellow -NoNewline
$confirm = Read-Host

if ($confirm -eq 'y' -or $confirm -eq 'Y') {
    Write-Host "`nPushing to GitHub..." -ForegroundColor Yellow
    Write-Host "(You'll be prompted for authentication)`n" -ForegroundColor Gray
    
    git push -u origin iOS
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "`n✓ Successfully pushed!" -ForegroundColor Green
        Write-Host "`nNext steps:" -ForegroundColor Cyan
        Write-Host "1. Go to: https://github.com/$username/$repoName" -ForegroundColor White
        Write-Host "2. Click 'Actions' tab" -ForegroundColor White
        Write-Host "3. Wait for build to complete (~2-3 minutes)" -ForegroundColor White
        Write-Host "4. Download 'Midnight-dylib' artifact" -ForegroundColor White
        Write-Host "5. Extract libmidnight.dylib and inject into Fortnite IPA`n" -ForegroundColor White
    } else {
        Write-Host "`n✗ Push failed!" -ForegroundColor Red
        Write-Host "`nCommon issues:" -ForegroundColor Yellow
        Write-Host "- Repository doesn't exist on GitHub (create it first)" -ForegroundColor Gray
        Write-Host "- Wrong authentication (use Personal Access Token, not password)" -ForegroundColor Gray
        Write-Host "- Network issues`n" -ForegroundColor Gray
        Write-Host "See PUSH_TO_GITHUB.md for detailed help." -ForegroundColor Cyan
    }
} else {
    Write-Host "`nPush cancelled. When ready, run:" -ForegroundColor Yellow
    Write-Host "  git push -u origin iOS`n" -ForegroundColor White
}
